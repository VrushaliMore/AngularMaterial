This project has moved!!!
==============================
You can now use the wizard directive within the Core renderer found here https://github.com/formio/ngFormio/blob/master/README.md#multi-page-forms.
